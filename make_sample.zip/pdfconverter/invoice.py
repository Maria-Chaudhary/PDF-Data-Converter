
import re
from typing import Dict, Any, Optional


# Matches amounts such as:
# PKR 2,500.00
# Rs. 2,500.00
# $1,250.00
# 2500.00
AMOUNT_PATTERN = re.compile(
    r"""
    (?P<currency>
        PKR|Rs\.?|USD|EUR|GBP|\$
    )?
    \s*
    (?P<amount>
        \d{1,3}(?:,\d{3})+(?:\.\d{1,2})?
        |
        \d+(?:\.\d{1,2})?
    )
    """,
    re.IGNORECASE | re.VERBOSE,
)


def _clean_text(page_text: Dict[int, str]) -> str:
    """Combine extracted PDF page text into one searchable string."""
    if not page_text:
        return ""

    return "\n".join(
        str(text or "")
        for text in page_text.values()
    )


def _find_first(patterns, text: str) -> Optional[str]:
    """Return the first captured value from a list of regex patterns."""
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).strip()
    return None


def _find_labeled_amount(
    text: str,
    labels,
    require_currency: bool = False,
) -> Optional[str]:
    """
    Find an amount near a label.

    Currency amounts are preferred so a tax percentage such as
    19.23% is not mistaken for the tax amount.
    """
    lines = text.splitlines()

    for line in lines:
        for label in labels:
            label_match = re.search(
                rf"\b{label}\b",
                line,
                re.IGNORECASE,
            )

            if not label_match:
                continue

            # Search the text after the label.
            after_label = line[label_match.end():]

            # If the amount is on the same line, prefer one with currency.
            currency_matches = []

            for amount_match in AMOUNT_PATTERN.finditer(after_label):
                currency = amount_match.group("currency")

                if currency:
                    currency_matches.append(amount_match)

            if currency_matches:
                selected = currency_matches[-1]
                return selected.group(0).strip()

            if require_currency:
                continue

            # For non-currency amounts, ignore percentages.
            amount_matches = []

            for amount_match in AMOUNT_PATTERN.finditer(after_label):
                end_pos = amount_match.end()

                remaining = after_label[end_pos:].lstrip()

                if remaining.startswith("%"):
                    continue

                amount_matches.append(amount_match)

            if amount_matches:
                selected = amount_matches[-1]
                return selected.group(0).strip()

    return None


def _find_amount_with_fallback(
    text: str,
    labels,
) -> Optional[str]:
    """
    First search for currency amounts, then allow plain numeric amounts.
    """
    amount = _find_labeled_amount(
        text,
        labels,
        require_currency=True,
    )

    if amount:
        return amount

    return _find_labeled_amount(
        text,
        labels,
        require_currency=False,
    )


def extract_invoice_data(page_text: Dict[int, str]) -> Dict[str, Any]:
    """
    Extract common invoice fields using rule-based pattern matching.

    This is heuristic extraction, not an AI model. Results may vary
    depending on the invoice layout and PDF text extraction quality.
    """
    text = _clean_text(page_text)

    # Invoice number
    invoice_number = _find_first(
        [
            r"\b(?:invoice\s*(?:number|no\.?|#)|bill\s*(?:number|no\.?|#))"
            r"\s*[:\-]?\s*([A-Z0-9][A-Z0-9\/\-_]*)"
        ],
        text,
    )

    # Invoice date
    invoice_date = _find_first(
        [
            r"\b(?:invoice\s*date|date\s*of\s*invoice|billing\s*date)"
            r"\s*[:\-]?\s*"
            r"(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}"
            r"|\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2})"
        ],
        text,
    )

    # Email
    email = _find_first(
        [
            r"\b([A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,})\b"
        ],
        text,
    )

    # Phone
    phone = _find_first(
        [
            r"\b(\+?\d[\d\s().\-]{7,}\d)\b"
        ],
        text,
    )

    # Subtotal
    subtotal = _find_amount_with_fallback(
        text,
        [
            r"sub[\s\-]?total",
        ],
    )

    # Tax: prioritize currency amounts after Tax/VAT/GST.
    # This avoids extracting a percentage such as 19.23%.
    tax = _find_amount_with_fallback(
        text,
        [
            r"tax(?:\s*\([^)]*\))?",
            r"vat(?:\s*\([^)]*\))?",
            r"gst(?:\s*\([^)]*\))?",
        ],
    )

    # Total: search specific total labels first.
    total = _find_amount_with_fallback(
        text,
        [
            r"grand\s*total",
            r"total\s*amount",
            r"amount\s*due",
            r"invoice\s*total",
        ],
    )

    # Only use a plain Total label if no specific total was found.
    if not total:
        total = _find_amount_with_fallback(
            text,
            [
                r"(?<!sub)\btotal\b",
            ],
        )

    return {
        "invoice_number": invoice_number,
        "invoice_date": invoice_date,
        "email": email,
        "phone": phone,
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
        "extraction_method": "rule-based",
    }
